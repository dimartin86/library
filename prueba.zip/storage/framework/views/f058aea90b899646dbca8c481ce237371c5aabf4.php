<?php $__env->startSection('content'); ?>
    <div class="home_container" style="padding-top: 220px;">
        <div id="welcome_main_section" align="center">
            <h1>Welcome</h1>
            <p>
                To Diego Martin's virtual library
            </p>

            <button class="btn btn-warning" onclick="window.location='library'">List books!</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\curso-laravel\prueba\resources\views/home.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\curso-laravel\prueba\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
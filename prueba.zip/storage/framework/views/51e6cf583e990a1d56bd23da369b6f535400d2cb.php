<?php $__env->startSection('content'); ?>
    <div class="home_container" style="padding-top: 40px;">
            <table class="table" id="tbl_library">
                <thead>
                    <th align="center">Author</th>
                    <th align="center">Title</th>
                    <th align="center">Year</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $arrBooks['docs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['author_name'][0]); ?></td>
                            <td><?php echo e($row['title']); ?></td>
                            <td><?php echo e($row['first_publish_year']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
    <script>
        $(function(){
            showDatatable('tbl_library');
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\curso-laravel\prueba\resources\views/pages/library.blade.php ENDPATH**/ ?>
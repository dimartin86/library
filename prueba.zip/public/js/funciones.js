function showDatatable(id){

    $('#'+id).DataTable( {
        destroy: true
    } );

}
